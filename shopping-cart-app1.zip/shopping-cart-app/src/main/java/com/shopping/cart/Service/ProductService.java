package com.shopping.cart.Service;

import java.util.List;

import com.shopping.cart.Payload.ProductDto;

public interface ProductService {
	      // create product
	
          ProductDto createProduct(ProductDto product); 
          // update product
		  ProductDto updateProduct(ProductDto product,Integer productId);
		  // get product
		  ProductDto getProductById(Integer productId);
		  // list product
		  List<ProductDto>getAllProducts();
		  // delete product
		  void deleteProduct(Integer productId);
		
}
	
	

 

