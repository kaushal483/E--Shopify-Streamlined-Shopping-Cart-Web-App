package com.shopping.cart.Exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.Builder;





//Custom Exception
@Builder
public class ResourceNotFoundException extends RuntimeException {
   
//	String resourceName;
//	String fieldName;
//	long fieldValue;
//	public ResourceNotFoundException(String resourceName, String fieldName, long fieldValue) {
//		super( String.format("%s not found", resourceName,fieldName,fieldValue));
//		this.resourceName = resourceName;
//		this.fieldName = fieldName;
//		this.fieldValue = fieldValue;
	
	
//	}
	public ResourceNotFoundException() {
		super("ResourceNotFoundException");
	}
	public ResourceNotFoundException(String message) {
		super(message);
	}
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> handleMethodArgsNotValidException(MethodArgumentNotValidException ex){
		Map<String,String> resp = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error)->{
			String fieldName = ((FieldError) error).getField();
			String message = error.getDefaultMessage();
			resp.put(fieldName, message);
		});
		return new ResponseEntity<Map<String,String>>(resp,HttpStatus.BAD_REQUEST);
	}
}

	
	