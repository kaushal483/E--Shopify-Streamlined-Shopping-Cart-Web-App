package com.shopping.cart.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shopping.cart.Entity.Product;

public interface  ProductRepo extends JpaRepository<Product,Integer>{

	

}
