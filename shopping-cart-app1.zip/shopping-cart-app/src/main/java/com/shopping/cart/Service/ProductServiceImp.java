package com.shopping.cart.Service;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.cart.Entity.Product;
import com.shopping.cart.Exception.ResourceNotFoundException;
import com.shopping.cart.Payload.ProductDto;
import com.shopping.cart.Repositories.ProductRepo;

@Service
public class ProductServiceImp implements ProductService {
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private ModelMapper mapper;

	@Override
	public ProductDto createProduct(ProductDto productDto) {
		// TODO Auto-generated method stub
		
		//dtoToEntity
				Product product = dtoToEntity(productDto);
			    Product saveProduct = this.productRepo.save(product);
			    
	    //entityToDto
			    
			    ProductDto newDto = entityToDto(saveProduct);
			    return newDto;
	}

	@Override
	public ProductDto updateProduct(ProductDto product, Integer productId) {
		// TODO Auto-generated method stub
		Product productDto = this.productRepo.findById(productId).orElseThrow(()-> new ResourceNotFoundException("Product not found"));
		product.setName(productDto.getName());
		product.setDescrip(productDto.getDescrip());
		product.setPrice(productDto.getPrice());
		Product updateProduct = this.productRepo.save(productDto);
		ProductDto productDto1 = this.entityToDto(updateProduct);
		return productDto1;
	
	}

	@Override
	public ProductDto getProductById(Integer productId) {
		
		Product product = this.productRepo.findById(productId).orElseThrow(()-> new ResourceNotFoundException("Product not found"));
		return this.entityToDto(product);
	}

	@Override
	public List<ProductDto> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> products= this.productRepo.findAll();
		List<ProductDto>  productDtos= products.stream().map(product -> this.entityToDto(product)).collect(Collectors.toList());
		return productDtos;
		
	}

	@Override
	public void deleteProduct(Integer productId) {
		// TODO Auto-generated method stub
		Product product = this.productRepo.findById(productId).orElseThrow(()-> new ResourceNotFoundException("Product not found"));
		this.productRepo.delete(product);
	}
	private ProductDto entityToDto(Product saveProduct ) {
		 return mapper.map(saveProduct, ProductDto.class);
	}
	
	
	
	private Product dtoToEntity(ProductDto productDto) {
		return mapper.map(productDto, Product.class);
				
	}

}
