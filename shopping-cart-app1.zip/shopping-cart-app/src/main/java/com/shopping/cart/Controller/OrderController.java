package com.shopping.cart.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.cart.Payload.OrderDto;

import com.shopping.cart.Service.OrderService;

@RestController
@RequestMapping("/or")
public class OrderController {
     @Autowired
	 private OrderService orderService;
     
    //Post- create order
     
     @PostMapping("/user/{userId}/product/{productId}/orders")
 	public ResponseEntity<OrderDto> createOrder(@RequestBody OrderDto orderDto,@PathVariable Integer userId,@PathVariable Integer productId){
 		OrderDto createOrderDto =this.orderService.createOrder(orderDto,userId,productId);
 		return new ResponseEntity<>(createOrderDto,HttpStatus.CREATED);
 		
 	}
     //Put - update order
     
     @PutMapping("{orderId}")
 	public ResponseEntity<OrderDto> updateOrder(@RequestBody OrderDto orderDto,@PathVariable("orderId")Integer orderId){
 		 OrderDto updatedOrder =this.orderService.updateOrder(orderDto,orderId);
 		 return ResponseEntity.ok(updatedOrder);
 	}
     // Get by user
     @GetMapping("/user/{userId}/orders")
     public ResponseEntity<List<OrderDto>> getOrderByUser(@PathVariable Integer userId){
    	 List<OrderDto> orders= this.orderService.getOrdersByUser(userId);
    	 return new ResponseEntity<List<OrderDto>>(orders, HttpStatus.OK);
    	 
        }
     
     //Get by product
     @GetMapping("/product/{productId}/orders")
     public ResponseEntity<List<OrderDto>> getOrderByProduct(@PathVariable Integer productId){
    	 List<OrderDto> orders= this.orderService.getOrdersByProduct(productId);
    	 return new ResponseEntity<List<OrderDto>>(orders, HttpStatus.OK);
     }
     
     // Delete - delete order
     
     @DeleteMapping("{orderId}")
     public ResponseEntity<?>deleteOrder(@PathVariable ("orderId") Integer orderId){
 		this.orderService.deleteOrder(orderId);
 		return ResponseEntity.ok(Map.of("Message","Order Deleted Successfully"));
 	}
 	
     
     

     
     
     
     
     
}
