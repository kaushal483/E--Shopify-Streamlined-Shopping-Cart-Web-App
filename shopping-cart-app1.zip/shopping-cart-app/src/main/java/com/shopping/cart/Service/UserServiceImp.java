package com.shopping.cart.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.cart.Entity.User;
import com.shopping.cart.Exception.ResourceNotFoundException;
import com.shopping.cart.Payload.UserDto;
import com.shopping.cart.Repositories.UserRepo;

@Service
public class UserServiceImp implements UserService {
     @Autowired
	private UserRepo userRepo;
     
    @Autowired
     private ModelMapper mapper;
     
     
	@Override
	
	public UserDto createUser(UserDto userDto) {
		
		//dtoToEntity
		User user = dtoToEntity(userDto);
	    User saveUser = this.userRepo.save(user);
	    
	    //entityToDto
	    
	    UserDto newDto = entityToDto(saveUser);
	    
		return newDto;
	}
	

	@Override
	public UserDto updateUser(UserDto userDto, Integer userId) {
		//Get the user
		User user = this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User not found"));
		user.setName(userDto.getName());
		user.setPassword(userDto.getPassword());
		 User updateUser = this.userRepo.save(user);
		 UserDto userDto1 = this.entityToDto(updateUser);
		return userDto1;
	}

	@Override
	public UserDto getUserById(Integer userId) {
		User user = this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User not found"));
		return this.entityToDto(user);
	}

	@Override
	public List<UserDto> getAllUsers() {
		 List<User> users= this.userRepo.findAll();
		 //using lamda stream api for listing of users
		 
		 List<UserDto>  userDtos= users.stream().map(user -> this.entityToDto(user)).collect(Collectors.toList());
		 
		
		return userDtos;
	}

	@Override
	public void deleteUser(Integer userId) {
		User user = this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User not found"));
		this.userRepo.delete(user);
	}
	private UserDto entityToDto(User saveUser ) {
		 return mapper.map(saveUser, UserDto.class);
	}
	
	
	
	private User dtoToEntity(UserDto userDto) {
		return mapper.map(userDto, User.class); 
				
	}
       
	
	
}
