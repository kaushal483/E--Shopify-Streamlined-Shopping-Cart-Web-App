package com.shopping.cart.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import com.shopping.cart.Entity.User;
import com.shopping.cart.Repositories.ProductRepo;
import com.shopping.cart.Repositories.UserRepo;
@Controller
public class HomeController {
	
	 private UserRepo userRepo;
	 private ProductRepo productRepo;
	 
	 public HomeController(UserRepo userRepo) {
	        this.userRepo = userRepo;
	    }
	 
	 
	//home handler
	 //model - data send to template
  @RequestMapping("/")
	public String home(Model model) {
		  model.addAttribute("title","home_shopping application");
		return "home";
	}
  @RequestMapping("/register")
  
  //register hander
	public String register(Model model) {
		  model.addAttribute("title","register_shopping application");
		  model.addAttribute("user",new User());
		return "register";
	}
  
  //handler- for registering user
   @RequestMapping( value="/do register",method= RequestMethod.POST)
   public String registerUser(@ModelAttribute("user")User user,Model model) {
	   
	   User result =  this.userRepo.save(user);
	   model.addAttribute("user",result);
		return "success";
   }
   @RequestMapping("/success")
   public String success(Model model) {
		  model.addAttribute("title","success");
		return "success";
	}
   @RequestMapping("/product")
   public String product(Model model) {
		  model.addAttribute("title","product");
		return "product";
	}
   @GetMapping("/login")
   public String showLoginForm() {
       return "login";
   }

   @PostMapping("/login")
   public String login(@RequestParam String email, @RequestParam String password, Model model) {
       // Here, you can implement your logic for user authentication
       // For simplicity, let's assume a valid username and password
       if ("user".equals(email) && "password".equals(password)) {
           model.addAttribute("email", email);
           return "dashboard";
       } else {
           model.addAttribute("error", "Invalid username or password");
           return "login";
       }
   }
}
  
   
   
   
   
  
 


