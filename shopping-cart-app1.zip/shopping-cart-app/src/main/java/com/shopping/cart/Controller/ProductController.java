package com.shopping.cart.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.cart.Payload.ProductDto;

import com.shopping.cart.Service.ProductService;

@RestController
@RequestMapping("/products")

public class ProductController {
	
	@Autowired
     private ProductService productService;
	
	//Post - create product
	
	@PostMapping
	public ResponseEntity<ProductDto> createProduct(@RequestBody ProductDto productDto){
		ProductDto createProductDto =this.productService.createProduct(productDto);
		return new ResponseEntity<>(createProductDto,HttpStatus.CREATED);
		
	}
	//Put - update product
	
	@PutMapping("{productId}")
	public ResponseEntity<ProductDto> updateProduct(@RequestBody ProductDto productDto,@PathVariable("productId")Integer productId){
		 ProductDto updatedProduct =this.productService.updateProduct(productDto,productId);
		 return ResponseEntity.ok(updatedProduct);
	}
	//Get - user get all products
	@GetMapping
    public ResponseEntity<List<ProductDto>> getAllProducts(){
   	 return ResponseEntity.ok(this.productService.getAllProducts());
    }
		
	// Delete - delete products
	
	@DeleteMapping("{productId}")
	public ResponseEntity<?>deleteProduct(@PathVariable ("productId") Integer productId){
		this.productService.deleteProduct(productId);
		return ResponseEntity.ok(Map.of("Message","Product Deleted Successfully"));
	}
	
	
	
}
	
	
	
	
	
	
	
	

