package com.shopping.cart.Payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Builder

public class ProductDto {
    private int id;
    private String name;
    private String descrip;
    private double price;
	
}
