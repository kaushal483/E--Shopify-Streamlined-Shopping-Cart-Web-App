package com.shopping.cart.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="products")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Product {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "product_id")
	private int id;
	@Column(name ="product_title")
    private String name;
    @Column(name = "product_descrip")
    private String descrip;
    @Column(name = "product_price")
    private double price;
     
    // having users purchase one product with multiple order
    @OneToMany(mappedBy = "product" , cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    //list of order associated with product
    private List<Order> orders = new ArrayList<>();
}
