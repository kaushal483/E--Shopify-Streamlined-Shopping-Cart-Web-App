package com.shopping.cart.Payload;
import jakarta.validation.constraints.Email;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDto {
    private int id;
    
    
      @Size(min = 5, max=20,message = "UserName must be in 5 characters")
    private String name;
    
      @Email(message = "Email in not valid")
    private String email;
    
    @NotEmpty
    @Size(min = 3,max = 10, message ="Password must be 3 and 10 characters")
    
    private String password;
	
    
    
}