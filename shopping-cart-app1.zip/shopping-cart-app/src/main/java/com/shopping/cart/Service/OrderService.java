package com.shopping.cart.Service;

import java.util.List;

import com.shopping.cart.Payload.OrderDto;


public interface OrderService {
	 // create order
	
    OrderDto createOrder(OrderDto order, Integer userId,Integer productId); 
    
    // update order
	  OrderDto updateOrder(OrderDto order,Integer orderId);
	  
	  // get single order
	  OrderDto getOrderById(Integer orderId);
	  
	  // get all order
	  List<OrderDto>getAllOrders();
	  
	  // delete order
	  void deleteOrder(Integer orderId);
	  
	  //get all order by product
	  List<OrderDto> getOrdersByProduct(Integer productId);
	  
	  //get all order by user
	  List<OrderDto> getOrdersByUser(Integer userId);
	
}
