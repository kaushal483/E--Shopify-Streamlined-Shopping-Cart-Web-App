package com.shopping.cart.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="orders")
@NoArgsConstructor
@Getter
@Setter
public class Order {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	 //@Column(name="order_id")
      private int id;
	@Column(name="order_item")
      private String item;
	@Column(name="order_total")
      private double total;
	
	//relationship between Order and Product entities.
   @ManyToOne 
   //add(join) the product_id column in the products table.
   @JoinColumn(name = "product_id")
   //represents the product associated with the order.
	private Product product;
   //relationship between Order and User entities.
	@ManyToOne
	//represents the user who placed the order.
	private User user;
	 

      
}
