package com.shopping.cart.Payload;

import com.shopping.cart.Entity.Product;
import com.shopping.cart.Entity.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
@Builder

public class OrderDto {
  
	private int id;
	
    private String item;
    
   
    private double total;
    
    private ProductDto product;
    
    private UserDto user;
}
