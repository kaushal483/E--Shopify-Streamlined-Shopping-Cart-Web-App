package com.shopping.cart.Service;

import java.util.List;

import com.shopping.cart.Payload.UserDto;

public interface UserService {
	
	//for creating user
	 UserDto createUser(UserDto user);//return userdto
	 UserDto updateUser(UserDto user,Integer userId);
	 UserDto getUserById(Integer userId);
	 
	 List<UserDto> getAllUsers();
	 void deleteUser(Integer userId);

}
