package com.shopping.cart.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.cart.Entity.Order;
import com.shopping.cart.Entity.Product;
import com.shopping.cart.Entity.User;
import com.shopping.cart.Exception.ResourceNotFoundException;
import com.shopping.cart.Payload.OrderDto;

import com.shopping.cart.Repositories.OrderRepo;
import com.shopping.cart.Repositories.ProductRepo;
import com.shopping.cart.Repositories.UserRepo;

@Service
public class OrderServiceImp implements OrderService {
	@Autowired
   private OrderRepo orderRepo;
	@Autowired
   private ModelMapper mapper;
	@Autowired
	private UserRepo userRepo;
	@Autowired
	private ProductRepo productRepo;
	@Override
	public OrderDto createOrder(OrderDto orderDto,Integer userId,Integer productId) {
		// TODO Auto-generated method stub
		User user = this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User not found"));
		Product product = this.productRepo.findById(productId).orElseThrow(()-> new ResourceNotFoundException("Product not found"));
	    
		
		//dtoToEntity
		Order order = dtoToEntity(orderDto);
		order.setUser(user);
		order.setProduct(product);
	    Order saveOrder = orderRepo.save(order);
	    
	  //entityToDto
	    
	    OrderDto newDto = entityToDto(saveOrder);
	    return newDto;
	    
		
	}

	@Override
	public OrderDto updateOrder(OrderDto order, Integer orderId) {
		// TODO Auto-generated method stub
		Order orderDto = this.orderRepo.findById(orderId).orElseThrow(()-> new ResourceNotFoundException("Order not found"));
		order.setItem(orderDto.getItem());
		order.setTotal(orderDto.getTotal());
		Order updateOrder = this.orderRepo.save(orderDto);
		OrderDto orderDto1 = this.entityToDto(updateOrder);
		
		return orderDto1;
	}

	@Override
	public OrderDto getOrderById(Integer orderId) {
		// TODO Auto-generated method stub
		Order order = this.orderRepo.findById(orderId).orElseThrow(()-> new ResourceNotFoundException("Product not found"));
		return this.entityToDto(order);
	}

	@Override
	public List<OrderDto> getAllOrders() {
		// TODO Auto-generated method stub
		List<Order> orders= this.orderRepo.findAll();
		List<OrderDto>  orderDtos= orders.stream().map(order -> this.entityToDto(order)).collect(Collectors.toList());
		return orderDtos;
		
	}

	@Override
	public void deleteOrder(Integer orderId) {
		// TODO Auto-generated method stub
		Order order = this.orderRepo.findById(orderId).orElseThrow(()-> new ResourceNotFoundException("Order not found"));
		this.orderRepo.delete(order);
		
	}
	
	private OrderDto entityToDto(Order saveOrder ) {
		 return mapper.map(saveOrder, OrderDto.class);
	}
	
	
	
	private Order dtoToEntity(OrderDto orderDto) {
		return mapper.map(orderDto, Order.class);
				
	}

	@Override
	public List<OrderDto> getOrdersByProduct(Integer productId) {
		// TODO Auto-generated method stub
		Product pro = this.productRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Product not found"));
	    List<Order> orders = this.orderRepo.findByProduct(pro);
	    List<OrderDto> orderDtos = orders.stream().map((order)->this.mapper.map(order, OrderDto.class)).collect(Collectors.toList());
	    return orderDtos;
	}

	@Override
	public List<OrderDto> getOrdersByUser(Integer userId) {
		// TODO Auto-generated method stub
		User user = this.userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("User not found"));
		List<Order> orders=this.orderRepo.findByUser(user);
		List<OrderDto> orderDtos = orders.stream().map((order)->this.mapper.map(order,OrderDto.class)).collect(Collectors.toList());
		return orderDtos;
	}

}
