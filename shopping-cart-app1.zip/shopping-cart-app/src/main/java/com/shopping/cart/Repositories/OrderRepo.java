package com.shopping.cart.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shopping.cart.Entity.Order;
import com.shopping.cart.Entity.Product;
import com.shopping.cart.Entity.User;

public interface OrderRepo extends JpaRepository<Order, Integer> {
     //custom finder method
	// list of order by user and product
	
	List<Order> findByUser(User user); 
	List<Order> findByProduct(Product product);
}
